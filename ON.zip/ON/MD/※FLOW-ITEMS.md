# 商品マスタ - データフロー図（2026/02/12更新）

## 🆕 最新の変更点（2026/02/12）

- ✅ **テーブル表示** - カード表示からExcel風テーブルに変更
- ✅ **初期非表示** - 画面を開いた時は一覧非表示、検索 or 全件表示で表示
- ✅ **インポート→確認フロー** - import.html → confirm-items.html → items.html
- ✅ **report.htmlでの商品自動生成** - 通報画面でも0件時に5件自動生成
- ✅ **本番モードのストレージキー** - `onetouch.items`（localStorageに統一）

---

## 🔄 最新のフロー

```
┌─────────────┐
│ ログイン    │
│ login.html  │
└──────┬──────┘
       │
       ▼
┌─────────────────────────┐
│ currentUser作成         │
│ sessionStorage保存      │
│ - companyCode           │
│ - officeCode            │
│ - role                  │
└──────┬──────────────────┘
       │
       ▼
  companyCode === 'TAMJ'?
       │
  ┌────┴────┐
  │ YES     │ NO
  │ (DEMO)  │ (本番)
  ▼         ▼
┌─────────────────┐  ┌─────────────────┐
│ sessionStorage  │  │ localStorage    │
│ 'demo.items'    │  │ 'onetouch.items'│ ← 🆕 キー統一
└────┬────────────┘  └────┬────────────┘
     │                    │
     │ 商品が0件？         │
     ▼                    │
┌─────────────────┐       │
│ 5個の商品を     │       │
│ 自動生成        │       │
│ - 空調: 1件     │       │
│ - 給湯: 1件     │       │
│ - 電気: 1件     │       │
│ - 水道: 1件     │       │
│ - 設備: 1件     │       │
└────┬────────────┘       │
     │                    │
     │ ※items.htmlだけでなく │
     │   report.htmlでも   │
     │   自動生成される 🆕  │
     │                    │
     └────────┬───────────┘
              │
              ▼
        ┌──────────────┐
        │ scope判定    │
        └──┬───────────┘
           │
    ┌──────┴──────┬───────────┬──────────┐
    │             │           │          │
    ▼             ▼           ▼          ▼
system_admin  company_admin  office_admin  staff
全商品        自社の全商品   自事業所      自事業所
                                         (通報画面で
                                          プルダウン選択)
              │
              ▼
        ┌──────────────────────┐
        │ 初期状態: 非表示 🆕   │
        │ ガイド表示            │
        │ 「検索条件を入力して  │
        │  ください」           │
        └──────┬───────────────┘
               │
        ┌──────┴──────┐
        │             │
        ▼             ▼
   [📋 全件表示]  [🔍 検索]
        │             │
        └──────┬──────┘
               │
               ▼
        ┌──────────────┐
        │ テーブル表示  │ ← 🆕 Excel風
        │ 50件/ページ   │
        └──────────────┘
```

---

## 📦 商品管理の画面フロー（2/12更新）

```
items.html（商品一覧）
   │
   │ 初期: ガイド表示（一覧非表示）🆕
   │
   ├─→ [📋 全件表示] → テーブルで全商品表示 🆕
   │
   ├─→ [🔍 検索] → 商品名・型番・メーカーで絞り込み
   │     └─→ カテゴリー選択 → 即フィルター
   │
   ├─→ [クリア] → 検索条件リセット → ガイド表示に戻る 🆕
   │
   ├─→ [新規登録] → モーダル → 保存 → テーブル再表示
   │
   ├─→ [インポート] → import.html
   │                      │
   │                      ├─→ CSV/Excelアップロード → パース → プレビュー
   │                      │
   │                      ├─→ PDFアップロード → PDF.jsテキスト抽出 🆕
   │                      │
   │                      ├─→ 列マッピング設定
   │                      │
   │                      └─→ [確認画面へ →]
   │                             │
   │                             ▼
   │                      ┌──────────────────────┐
   │                      │ confirm-items.html   │ ← 🆕 新規作成
   │                      │ （インポート確認画面） │
   │                      ├──────────────────────┤
   │                      │ ・テーブルで表示      │
   │                      │ ・各フィールド編集可  │
   │                      │ ・信頼度表示          │
   │                      │   高(85%↑)=緑        │
   │                      │   中(60-85%)=黄      │
   │                      │   低(60%↓)=赤        │
   │                      │ ・カテゴリ推定ボタン  │
   │                      │ ・全角→半角ボタン    │
   │                      │ ・行削除ボタン        │
   │                      └──────────┬───────────┘
   │                                 │
   │                          [確定して商品マスタに登録]
   │                                 │
   │                                 ▼
   │                          DocumentStorage.confirmLineItems()
   │                                 │
   │                                 ├─→ LineItems → Items に変換
   │                                 ├─→ 商品マスタに保存
   │                                 ├─→ Document status='confirmed'
   │                                 └─→ items.html に遷移
   │
   └─→ [エクスポート] → CSV出力
```

---

## 📊 テーブル表示の仕様（2/12新規）

### 表示カラム
| # | カラム | 説明 |
|---|--------|------|
| 1 | 商品名 | 長い場合は省略（ホバーで全文） |
| 2 | メーカー | |
| 3 | 型番 | |
| 4 | カテゴリー | バッジ表示（紫系） |
| 5 | 担当業者 | バッジ表示（青系） |
| 6 | 在庫 | |
| 7 | 単価 | ¥フォーマット |
| 8 | 操作 | 編集・削除ボタン |

### CSS
```css
.items-table thead th {
    position: sticky;  /* ヘッダー固定 */
    top: 0;
}
.badge-category { background: #f3e5f5; color: #7b1fa2; }
.badge-partner { background: #e3f2fd; color: #1565c0; }
```

### レスポンシブ
- スマホ: overflow-x スクロール対応

---

## 📊 商品データ構造

### **localStorage (本番)**
```
キー: 'onetouch.items'

構造:
[
  {
    itemId: 'ITEM-20260212-XXXX',
    companyCode: 'COMP001',
    officeCode: 'COMP001-J0001',
    name: '商品名',
    maker: 'メーカー名',
    model: '型番',
    category: '空調',
    assignedPartnerId: 'PARTNER-001',
    assignedPartnerName: '東京設備工業株式会社',
    unit: '台',
    price: 150000,
    stock: 1,
    createdAt: '2026-02-12T00:00:00Z',
    updatedAt: '2026-02-12T00:00:00Z'
  }
]
```

### **sessionStorage (DEMO)**
```
キー: 'demo.items'
構造: 同上
```

---

## 📄 書類・明細データ構造（2/12新規）

### **管理: document-storage.js**

```
DEMOモード:
  sessionStorage['demo.documents']
  sessionStorage['demo.lineItems']

本番モード:
  localStorage['onetouch.documents']
  localStorage['onetouch.lineItems']
```

### Document（書類）
```javascript
{
  docId: 'DOC-20260212-XXXX',
  companyCode: 'TAMJ',
  officeCode: 'TAMJ-J0001',
  fileName: '見積書.pdf',
  status: 'pending' | 'confirmed',
  uploadedAt: '2026-02-12T00:00:00Z',
  confirmedAt: null
}
```

### LineItem（明細行）
```javascript
{
  lineId: 'LINE-XXXXXX',
  docId: 'DOC-20260212-XXXX',
  name: '車いす',
  maker: '松永製作所',
  model: 'AR-501',
  quantity: 1,
  price: 45000,
  category: '福祉用具',
  confidence: 0.92,  // OCR信頼度
  status: 'pending'
}
```

### confirmLineItems() のフロー
```
LineItems → Items に変換:
  - lineId → itemId 生成
  - docId → sourceDocId として保持
  - quantity → stock
  - confidence は破棄（商品マスタには不要）
  
Document status → 'confirmed'
LineItems → 削除
Items → 商品マスタ（demo.items or onetouch.items）に追加
```

---

## 🎭 DEMO vs 本番 比較表

| 項目 | DEMO (TAMJ) | 本番 |
|------|-------------|------|
| ストレージ | sessionStorage | localStorage |
| ストレージキー | demo.items | onetouch.items |
| データ永続性 | ブラウザを閉じたら消える | 永続的 |
| ログアウト時 | **データ保持** 🆕 | データ保持 |
| 初期データ | 5個自動生成 | 空 |
| 自動生成場所 | items.html + **report.html** 🆕 | — |
| 商品登録 | ✅ OK | ✅ OK |
| 商品編集 | ✅ OK | ✅ OK |
| 商品削除 | ✅ OK | ✅ OK |
| インポート | ✅ OK（CSV/Excel/PDF） 🆕 | ✅ OK |
| 確認画面 | ✅ confirm-items.html 🆕 | ✅ confirm-items.html |

---

## 🔐 権限マトリックス

| 操作 | system_admin | company_admin | office_admin | staff |
|------|--------------|---------------|--------------|-------|
| 全商品閲覧 | ✅ | ❌ | ❌ | ❌ |
| 自社商品閲覧 | ✅ | ✅ | ❌ | ❌ |
| 自事業所商品閲覧 | ✅ | ✅ | ✅ | ❌※ |
| 通報画面で商品選択 | — | — | — | ✅ |
| 商品登録 | ✅ | ✅ | ✅ | ❌ |
| 商品編集 | ✅ | ✅ | ✅ | ❌ |
| 商品削除 | ✅ | ✅ | ✅ | ❌ |
| インポート | ✅ | ✅ | ✅ | ❌ |
| エクスポート | ✅ | ✅ | ✅ | ❌ |

※ スタッフはitems.htmlにアクセスできないが、report.htmlのプルダウンで商品を選択できる

---

## 📁 ファイル構成

```
/ON/
├── item-storage.js          ← ハイブリッドストレージ（DEMO/本番切替）
├── document-storage.js      ← 🆕 書類・明細管理（DEMO/本番切替）
├── items.html               ← 商品一覧（テーブル表示）
├── import.html              ← ファイル取込（CSV/Excel/PDF）
├── confirm-items.html       ← 🆕 インポート確認画面
├── master-top.html          ← 管理TOP
├── demo-mode.js             ← DEMOモード判定
├── report.html              ← 通報画面（商品自動生成対応）
└── unified-header.js        ← 統一ヘッダー
```
