# ワンタッチ管理システム - 全体フロー図（2026/02/12更新）

## 🆕 最新の変更点（2026/02/12）

### 変更された機能
- ✅ **商品マスタ テーブル表示** - カード表示からExcel風テーブルに変更
- ✅ **商品マスタ 初期非表示** - 検索ボタン or 全件表示ボタンで表示
- ✅ **インポート→確認フロー** - import.html → confirm-items.html → items.html 接続完了
- ✅ **document-storage.js 書き直し** - DEMOモード完全対応（sessionStorage/localStorage）
- ✅ **report.htmlでの商品自動生成** - items.htmlを開かなくても通報画面で5件生成
- ✅ **ログアウト時のデータ保持** - demo.*/onetouch.* キーを保持、ログアウトでデータ消えない
- ✅ **業者画面の改善** - 事業所名・設備名表示、コメント送信後自動閉じ、DEMOバナー
- ✅ **通報履歴の改善** - 本社管理者が全事業所の通報を閲覧可能

### 削除されたファイル
- ❌ **test-data-creator.html** - 削除（本番動作確認のため）
- ❌ **contractor-login.html** - 削除（login.htmlに統合済み）

### DEMOモードと本番モードの違い

| 項目 | DEMOモード（TAMJ） | 本番モード | システム管理者 |
|------|-------------------|-----------|---------------|
| ストレージ | sessionStorage | localStorage | localStorage |
| 通報データキー | onetouch.reports (session) | onetouch.reports (local) | onetouch.reports (local) |
| 商品データキー | demo.items (session) | onetouch.items (local) | — |
| 業者データ | 自動生成（3社） | 手動登録 | 見えない |
| 商品データ | 自動生成（5個） | 手動登録 | 見えない |
| データ永続性 | ブラウザ閉じると消える | 永続的 | 永続的 |
| ログアウト時 | **データ保持**（demo.*/onetouch.*） | データ保持 | データ保持 |
| 対象ユーザー | TAMJ社員（demo-staff等） | 契約会社 | システム管理者 |

---

## 📱 ログインフロー

```
┌────────────────────────┐
│     login.html         │
│   （統一ログイン画面）  │
└───────┬────────────────┘
        │
        │ 会社コード + ID + パスワード
        │
        ▼
  ┌─────────────┐
  │ 認証処理    │
  └─────┬───────┘
        │
    ┌───┴───┐
    │ role? │
    └───┬───┘
        │
  ┌─────┴─────┬─────────┬─────────┬─────────┐
  │           │         │         │         │
  ▼           ▼         ▼         ▼         ▼
contractor  staff   office_   company_  system_
                    admin     admin     admin
  │           │         │         │         │
  ▼           ▼         ▼         ▼         ▼
contractor  report   master-   master-   system-
-dashboard  .html    top.html  top.html  admin.html
```

---

## 🏢 管理者フロー（office_admin / company_admin）

```
┌────────────────────┐
│   master-top.html  │
│   （管理画面TOP）   │
└─────────┬──────────┘
          │
   ┌──────┴──────┬──────────┬──────────┬──────────┐
   │             │          │          │          │
   ▼             ▼          ▼          ▼          ▼
account-     office-    partner-    items.html  system-
master       master     master                  settings
.html        .html      .html                   .html
   │             │          │          │          │
アカウント    事業所     取引先      商品        システム
管理         管理       管理        管理        設定
```

### **商品管理の詳細フロー（2/12更新）:**
```
items.html（商品一覧 ※テーブル表示）
   │
   │ 初期状態: 一覧非表示（ガイド表示）
   │
   ├─→ [📋 全件表示] → テーブルで全商品表示
   │
   ├─→ [🔍 検索] → 商品名・型番・メーカーで絞り込み
   │
   ├─→ [新規登録] → モーダル → 保存 → テーブル再表示
   │
   ├─→ [インポート] → import.html
   │                      │
   │                      ├─→ CSV/Excel/PDFアップロード
   │                      │     └─→ PDF.jsでテキスト抽出（ローカル）
   │                      │
   │                      ├─→ プレビュー → 列マッピング
   │                      │
   │                      └─→ [確認画面へ →]
   │                             │
   │                             ▼
   │                      confirm-items.html ← 🆕
   │                             │
   │                             ├─→ データ確認（テーブル/編集可能）
   │                             ├─→ カテゴリ推定 / 全角→半角
   │                             ├─→ 信頼度表示（高/中/低）
   │                             └─→ [確定して商品マスタに登録]
   │                                    │
   │                                    ▼
   │                              items.html に遷移
   │
   └─→ [エクスポート] → CSV出力
```

---

## 👷 スタッフフロー

```
┌────────────────┐
│  report.html   │
│  （通報画面）   │
└────────┬───────┘
         │
         │ ※商品データが0件の場合、5件を自動生成 🆕
         │
    ┌────┴────┐
    │         │
    ▼         ▼
 [新規通報]  [通報履歴]
    │         │
    │         ├─→ 通報ID
    │         ├─→ ステータス（未対応/対応中/完了）
    │         ├─→ 業者名
    │         ├─→ 業者コメント
    │         └─→ 対応時間
    │
    ▼
 ┌────────────┐
 │ モーダル   │
 ├────────────┤
 │ 設備名     │ ← プルダウンから選択（商品マスタ連動）
 │ カテゴリー │ ← 設備を選択すると自動設定
 │ 緊急度     │
 │ 場所       │
 │ 状況       │
 └─────┬──────┘
       │
       ▼
    [通報する]
       │
       ▼
 ┌─────────────────┐
 │ 業者自動割り当て │
 └────────┬────────┘
          │
          │ カテゴリー一致 & 会社紐付き
          │
          ▼
    assignedPartnerId 設定
```

---

## 🔧 業者フロー（Phase 10）

```
┌────────────────────┐
│    login.html      │
│ 会社コード: P001   │
│ ID: p001-yamada    │
└─────────┬──────────┘
          │ role: 'contractor'
          │
          ▼
┌──────────────────────┐
│ contractor-dashboard │
│     .html            │
│  （業者ダッシュボード）│
│                      │
│ ⚠️ DEMOバナー表示 🆕 │
└────────┬─────────────┘
         │
    ┌────┴────┬────────┬────────┐
    │         │        │        │
    ▼         ▼        ▼        ▼
  未対応    対応中   対応不可   完了
    │         │        │        │
    └────┬────┴────┬───┴────────┘
         │          │
         ▼          ▼
    [通報詳細]  [コメント追加]
         │          │
         │  表示項目（2/12追加）:
         │  ・通報元（事業所名）🆕
         │  ・設備名 🆕
         │  ・カテゴリー
         │  ・緊急度
         │  ・場所
         │  ・状況
         │          │
         └────┬─────┘
              │
              ▼
        [コメント送信]
              │
              ├─→ 詳細画面が自動で閉じる 🆕
              ├─→ カードにコメント表示 🆕
              │
              ▼
        [ステータス更新]
              │
              ├─→ sessionStorage + localStorage 両方に保存 🆕
              │
              └─→ スタッフ側に反映
                    ↓
               report.html
               通報履歴に表示
```

---

## 🔄 通報の完全フロー（スタッフ ↔ 業者）

```
【スタッフ側】report.html
   │
   │ 1. 通報送信（設備名・カテゴリー・緊急度）
   │
   ▼
カテゴリーで業者自動検索
   │
   │ categories.includes(カテゴリー)
   │ assignedCompanies.includes('TAMJ')
   │
   ▼
assignedPartnerId: 'PARTNER-001'
contractorStatus: '未対応'
   │
   ▼
sessionStorage に保存（DEMOモード時）
   │
   ├──────────────────────────┐
   │                          │
   ▼                          ▼
【業者側】                  【スタッフ側】
contractor-dashboard        report.html
   │                       通報履歴
   │ ※session+local        │
   │  両方を読む 🆕         │ ステータス: 未対応
   │                       │ 業者: 東京設備工業
   │ 2. 通報確認            │
   │ 事業所名表示 🆕        │
   │ 設備名表示 🆕          │
   ▼                       │
コメント入力                │
「現場確認します」           │
   │                       │
   ▼                       │
[コメント送信]              │
   │                       │
   ├─ 詳細画面自動閉じ 🆕   │
   ├─ カードにコメント表示 🆕│
   │                       │
   ▼                       │
contractorStatus: '対応中'  │
contractorComments に追加   │
   │                       │
   ▼                       │
session + local 両方更新 🆕 │
   │                       │
   └──────────────────────┤
                           │
                      ページ再読み込み
                           │
                           ▼
                    ステータス: 対応中
                    💬 現場確認します
                           │
                           ▼
                      業者が完了報告
                           │
                           ▼
                    ステータス: 完了
                    ⏱️ 対応時間: 3時間
```

---

## 📊 データストレージ構造（2/12更新）

### **ユーザーデータ:**
```
sessionStorage: 'currentUser'         ← ログイン時に設定
sessionStorage: 'currentContractor'   ← 業者ログイン時に追加設定

DEMOモード判定:
currentUser.companyCode === 'TAMJ'
```

### **業者データ:**
```
sessionStorage: 'partners'  ← DEMOモード時（自動生成）
localStorage: 'partners'    ← 本番モード時

構造:
{
  partnerId: 'PARTNER-001',
  partnerCode: 'P001',
  loginId: 'p001-yamada',
  password: 'password123',
  categories: ['空調', '給湯', '電気'],
  assignedCompanies: ['TAMJ'],
  status: 'active'
}
```

### **通報データ:**
```
DEMOモード: sessionStorage['onetouch.reports']
本番モード: localStorage['onetouch.reports']

※業者画面（contractor-dashboard）は両方を読んでマージする 🆕

構造:
{
  id: 'RPT-20260212-001',
  userId: 'demo-staff',
  reporter: 'デモスタッフ',
  companyCode: 'TAMJ',
  officeCode: 'TAMJ-J0001',
  officeName: '東京事業所',
  title: 'エアコン 1号機',
  category: '空調',
  priority: '高',
  location: '2F 会議室',
  description: '冷房が効かない、異臭がする',
  timestamp: '2026-02-12T14:30:00Z',
  
  // 業者情報（自動割り当て）
  assignedPartnerId: 'PARTNER-001',
  assignedPartnerName: '東京設備工業株式会社',
  contractorStatus: '未対応',
  contractorComments: [
    {
      author: '東京設備工業株式会社',
      text: '現場確認します',
      timestamp: '2026-02-12T15:00:00Z'
    }
  ],
  resolvedAt: null
}
```

### **商品データ:**
```
DEMOモード:  sessionStorage['demo.items']
本番モード:  localStorage['onetouch.items']    ← 🆕 キー名統一

※report.htmlでも0件時に5件自動生成 🆕

構造:
{
  itemId: 'ITEM-DEMO-001',
  companyCode: 'TAMJ',
  officeCode: 'TAMJ-J0001',
  name: 'エアコン 1号機',
  maker: 'ダイキン',
  model: 'AN22XRS-W',
  category: '空調',
  assignedPartnerId: 'PARTNER-001',
  assignedPartnerName: '東京設備工業株式会社',
  unit: '台',
  price: 150000,
  stock: 1
}
```

### **書類・明細データ（インポート用）: 🆕**
```
DEMOモード:  sessionStorage['demo.documents'] / sessionStorage['demo.lineItems']
本番モード:  localStorage['onetouch.documents'] / localStorage['onetouch.lineItems']

管理: document-storage.js

フロー:
import.html → DocumentStorage.addDocument() + addLineItems()
    ↓
confirm-items.html → DocumentStorage.getLineItemsByDoc() → 確認・編集
    ↓
DocumentStorage.confirmLineItems() → 商品マスタに登録 → items.html
```

---

## 🔐 権限とアクセス制御

| Role | アクセス可能画面 | 通報履歴の範囲 |
|------|----------------|---------------|
| **system_admin** | 全画面 | 全社 |
| **company_admin** | master-top, account/office/partner-master, items, system-settings, report-history | **自社全事業所** 🆕 |
| **office_admin** | master-top, account-master, items, report-history | 自事業所 |
| **staff** | report | 自分の通報のみ |
| **contractor** | contractor-dashboard | 自社に割り当てられた通報 |

---

## 🚪 ログアウト処理（2/12更新）

```
ログアウトボタン押下
    ↓
confirm('ログアウトしますか？')
    ↓ OK
sessionStorageから保持対象キーを退避:
    - demo.*  キー（DEMOデータ）
    - onetouch.* キー（通報データ等）
    ↓
sessionStorage.clear()
    ↓
保持対象キーを復元
    ↓
localStorageのログイン情報クリア:
    - currentUser, currentAccount
    - ONE_loggedIn, ONE_userId, ONE_userName
    ↓
window.location.replace('login.html')
    ※ replace使用 → 戻るボタンで前画面に戻れない
```

---

## 📱 削除された画面

- ❌ **contractor-login.html** → login.html に統合
- ❌ **test-data-creator.html** → 削除

---

## 🎯 Phase 10-11 で追加された機能

1. ✅ 業者ログイン（login.html から）
2. ✅ 業者ダッシュボード（contractor-dashboard.html）
3. ✅ 業者自動割り当て（カテゴリーベース）
4. ✅ 通報履歴表示（report.html）
5. ✅ 業者コメント表示（スタッフ側）
6. ✅ ステータス連携（未対応→対応中→完了）
7. ✅ 対応時間表示
8. ✅ 商品マスタ テーブル表示 + 初期非表示 🆕
9. ✅ インポート→確認→登録フロー 🆕
10. ✅ 業者画面に事業所名・設備名表示 🆕
11. ✅ 本社管理者の全事業所通報閲覧 🆕
12. ✅ ログアウト時のデータ保持 🆕
